package no.uio.ifi.asp.scanner;

import java.io.*;
import java.util.*;

import no.uio.ifi.asp.main.*;
import static no.uio.ifi.asp.scanner.TokenKind.*;
//import no.uio.ifi.asp.scanner.Token.*;

public class Scanner {
    private LineNumberReader sourceFile = null;
    private String curFileName;
    private ArrayList<Token> curLineTokens = new ArrayList<>();
    private int indents[] = new int[100];
    private int numIndents = 0;
    private final int tabDist = 4;


    public Scanner(String fileName) {
	curFileName = fileName;
	indents[0] = 0;  numIndents = 1;

	try {
	    sourceFile = new LineNumberReader(
			    new InputStreamReader(
				new FileInputStream(fileName),
				"UTF-8"));
	} catch (IOException e) {
	    scannerError("Cannot read " + fileName + "!");
	}
    }


    private void scannerError(String message) {
	String m = "Asp scanner error";
	if (curLineNum() > 0)
	    m += " on line " + curLineNum();
	m += ": " + message;

	Main.error(m);
    }


    public Token curToken() {
	while (curLineTokens.isEmpty()) {
	    readNextLine();
	}
	return curLineTokens.get(0);
    }


    public void readNextToken() {
	if (! curLineTokens.isEmpty())
	    curLineTokens.remove(0);
    }


    public boolean anyEqualToken() {
	for (Token t: curLineTokens) {
	    if (t.kind == equalToken) return true;
	}
	return false;
    }


    private void readNextLine() {
	curLineTokens.clear();

	// Read the next line:
	String line = null;
	try {
	    line = sourceFile.readLine();
	    if (line == null) {
		sourceFile.close();
		sourceFile = null;
	    } else {
		Main.log.noteSourceLine(curLineNum(), line);
	    }
	} catch (IOException e) {
	    sourceFile = null;
	    scannerError("Unspecified I/O error!");
	}

	//-- Must be changed in part 1:

  if(line != null){
    // sjekk for tom linje eller kommentar
    boolean content_to_Token = true;
    int teller_bla_kom = 0;
    int comment = line.length();
    for(int tom_eller_kommentar = 0; tom_eller_kommentar < line.length(); tom_eller_kommentar ++){
      //merker første #
      if(line.charAt(tom_eller_kommentar) == '#'){
        if(comment > tom_eller_kommentar){
          comment = tom_eller_kommentar;
        }
      }

      if(line.charAt(tom_eller_kommentar) == ' ' ||line.charAt(tom_eller_kommentar) == '\t' || line.charAt(tom_eller_kommentar) == '#'){
        teller_bla_kom ++;
      }
      //slår kun ut hvis # er første tegn utenom tabs og blanks
      if(teller_bla_kom == comment +1){
        content_to_Token = false;
        break;
      }
    }
    if(line.length() == 0){
      content_to_Token = false;
    }


    if(content_to_Token == true){
        // fjern tabs i front
      line = expandLeadingTabs(line);

      //tell indents
      int tempNumIndents = findIndent(line);
      //legg til indentToken til curLineTokens
      if(tempNumIndents > indents[numIndents - 1]){
        indents[numIndents] = tempNumIndents;
        numIndents ++;
        curLineTokens.add(new Token(indentToken,curLineNum()));
      }else{
        //legger til dedentTokens til curLineTokens
        while(tempNumIndents < indents[numIndents - 1]){
          //test for indeks error
          if (numIndents == 1 && tempNumIndents != 0 ){
            scannerError("Indekserings error");
          }
          curLineTokens.add(new Token(dedentToken,curLineNum()));
          numIndents --;
        }
      }

      //les gjennom string og konstruer lineTokens
      char[] cLine = line.toCharArray();
      int tell_for_split = 0;

      //start paa leting etter ord
      while(tell_for_split < cLine.length){
        if(tell_for_split < cLine.length){
          if (cLine[tell_for_split] == ' ' || cLine[tell_for_split] == '\t'){
            tell_for_split++;
          }
        }

        if(tell_for_split < cLine.length-1){
          //finn string
          if (cLine[tell_for_split] == '\"' || cLine[tell_for_split] == '\''){
            StringBuilder sb = new StringBuilder();
            int slutt_av_string = tell_for_split +1;
            while(slutt_av_string < cLine.length-1 && !(cLine[slutt_av_string] == '\"' || cLine[slutt_av_string] == '\'')){
              slutt_av_string++;
            }
            while(tell_for_split <= slutt_av_string){
              sb.append(cLine[tell_for_split]);
              tell_for_split++;
            }
            Token tempStrToken = new Token(stringToken,curLineNum());
            sb.deleteCharAt(0);
            sb.deleteCharAt(sb.length() - 1);
            tempStrToken.stringLit = sb.toString();
            curLineTokens.add(tempStrToken);
          }
        }

        if(tell_for_split < line.length()){
          //finn int or float
          if (isDigit(cLine[tell_for_split])){
            StringBuilder sb = new StringBuilder();
            int slutt_av_tall = tell_for_split+1;
            boolean isFloat = false;
            if(slutt_av_tall < cLine.length){
              while(slutt_av_tall <= cLine.length-1 && (isDigit(cLine[slutt_av_tall]) || cLine[slutt_av_tall] == '.') ){
                if(cLine[slutt_av_tall] == '.'){
                  isFloat = true;
                }
                slutt_av_tall++;
              }
            }
            while(tell_for_split <= cLine.length-1 && tell_for_split < slutt_av_tall ){
              sb.append(cLine[tell_for_split]);
              tell_for_split++;
            }

            if(isFloat == true){
              Token tempflotToken = new Token(floatToken,curLineNum());
              tempflotToken.floatLit = Double.parseDouble(sb.toString());
              curLineTokens.add(tempflotToken);
            }else{
              Token tempIntToken = new Token(integerToken,curLineNum());
              tempIntToken.integerLit = Integer.parseInt(sb.toString().trim());
              curLineTokens.add(tempIntToken);
            }

          }
        }


        if(tell_for_split < line.length()){
          if (isLetterAZ(cLine[tell_for_split])){
            boolean not_special_sign = true;

            if(tell_for_split < line.length()-1){ //to avoid out of bounds error
              if(cLine[tell_for_split] == 'i' && cLine[tell_for_split +1] == 'f'){
                curLineTokens.add(new Token(ifToken,curLineNum()));
                tell_for_split = tell_for_split + 2;
                not_special_sign = false;
              }
              else if(cLine[tell_for_split] == 'i' && cLine[tell_for_split +1] == 'n'){

                if(tell_for_split +1 == cLine.length-1 || isLetterAZ(cLine[tell_for_split +2]) == false){

                  curLineTokens.add(new Token(inToken,curLineNum()));
                  tell_for_split = tell_for_split + 2;
                  not_special_sign = false;
                }
              }
              else if(cLine[tell_for_split] == 'o' && cLine[tell_for_split +1] == 'r'){
                curLineTokens.add(new Token(orToken,curLineNum()));
                tell_for_split = tell_for_split + 2;
                not_special_sign = false;
              }
            }

            if(tell_for_split < line.length()-2){ //to avoid out of bounds error
              if(cLine[tell_for_split] == 'a' && cLine[tell_for_split +1] == 'n' && cLine[tell_for_split +2] == 'd'){
                curLineTokens.add(new Token(andToken,curLineNum()));
                tell_for_split = tell_for_split + 3;
                not_special_sign = false;
              }
              else if(cLine[tell_for_split] == 'd' && cLine[tell_for_split +1] == 'e' && cLine[tell_for_split +2] == 'f'){
                curLineTokens.add(new Token(defToken,curLineNum()));
                tell_for_split = tell_for_split + 3;
                not_special_sign = false;
              }
              else if(cLine[tell_for_split] == 'f' && cLine[tell_for_split +1] == 'o' && cLine[tell_for_split +2] == 'r'){
                curLineTokens.add(new Token(forToken,curLineNum()));
                tell_for_split = tell_for_split + 3;
                not_special_sign = false;
              }
              else if(cLine[tell_for_split] == 'n' && cLine[tell_for_split +1] == 'o' && cLine[tell_for_split +2] == 't'){
                curLineTokens.add(new Token(notToken,curLineNum()));
                tell_for_split = tell_for_split + 3;
                not_special_sign = false;
              }
            }
            if(tell_for_split < line.length()-3){ //to avoid out of bounds error
              if(cLine[tell_for_split] == 'e' && cLine[tell_for_split +1] == 'l' && cLine[tell_for_split +2] == 'i' && cLine[tell_for_split +3] == 'f'){
                curLineTokens.add(new Token(elifToken,curLineNum()));
                tell_for_split = tell_for_split + 4;
                not_special_sign = false;
              }
              else if(cLine[tell_for_split] == 'e' && cLine[tell_for_split +1] == 'l' && cLine[tell_for_split +2] == 's' && cLine[tell_for_split +3] == 'e'){
                curLineTokens.add(new Token(elseToken,curLineNum()));
                tell_for_split = tell_for_split + 4;
                not_special_sign = false;
              }
              else if(cLine[tell_for_split] == 'N' && cLine[tell_for_split +1] == 'o' && cLine[tell_for_split +2] == 'n' && cLine[tell_for_split +3] == 'e'){
                curLineTokens.add(new Token(noneToken,curLineNum()));
                tell_for_split = tell_for_split + 4;
                not_special_sign = false;
              }
              else if(cLine[tell_for_split] == 'p' && cLine[tell_for_split +1] == 'a' && cLine[tell_for_split +2] == 's' && cLine[tell_for_split +3] == 's'){
                curLineTokens.add(new Token(passToken,curLineNum()));
                tell_for_split = tell_for_split + 4;
                not_special_sign = false;
              }
              else if(cLine[tell_for_split] == 'T' && cLine[tell_for_split +1] == 'r' && cLine[tell_for_split +2] == 'u' && cLine[tell_for_split +3] == 'e'){
                curLineTokens.add(new Token(trueToken,curLineNum()));
                tell_for_split = tell_for_split + 4;
                not_special_sign = false;
              }
            }
            if(tell_for_split < line.length()-4){ //to avoid out of bounds error
              if(cLine[tell_for_split] == 'w' && cLine[tell_for_split +1] == 'h' && cLine[tell_for_split +2] == 'i' && cLine[tell_for_split +3] == 'l' && cLine[tell_for_split +4] == 'e'){
                curLineTokens.add(new Token(whileToken,curLineNum()));
                tell_for_split = tell_for_split + 5;
                not_special_sign = false;
              }
              else if(cLine[tell_for_split] == 'F' && cLine[tell_for_split +1] == 'a' && cLine[tell_for_split +2] == 'l' && cLine[tell_for_split +3] == 's' && cLine[tell_for_split +4] == 'e'){
                curLineTokens.add(new Token(falseToken,curLineNum()));
                tell_for_split = tell_for_split + 5;
                not_special_sign = false;
              }
            }
            if(tell_for_split < line.length()-5){ //to avoid out of bounds error
              if(cLine[tell_for_split] == 'r' && cLine[tell_for_split +1] == 'e' && cLine[tell_for_split +2] == 't' && cLine[tell_for_split +3] == 'u' && cLine[tell_for_split +4] == 'r' && cLine[tell_for_split +5] == 'n'){
                curLineTokens.add(new Token(returnToken,curLineNum()));
                tell_for_split = tell_for_split + 6;
                not_special_sign = false;
              }
            }
            if(not_special_sign){
              //lage navn token
              StringBuilder sb = new StringBuilder();
              int slutt_av_navn = tell_for_split+1;
              if(slutt_av_navn < cLine.length){
                while(slutt_av_navn < cLine.length && (isLetterAZ(cLine[slutt_av_navn]) || isDigit(cLine[slutt_av_navn]) )){
                  slutt_av_navn++;
                }
              }

              while(tell_for_split <= cLine.length-1 && tell_for_split < slutt_av_navn){
                sb.append(cLine[tell_for_split]);
                tell_for_split++;
              }
              Token tempNamToken = new Token(nameToken,curLineNum());
              tempNamToken.name = sb.toString();
              curLineTokens.add(tempNamToken);
            }

          }
        }


        if(tell_for_split < line.length()){
          //finn *
          if(cLine[tell_for_split] == '*'){
            curLineTokens.add(new Token(astToken,curLineNum()));
            tell_for_split++;
          }
        }

        if(tell_for_split < line.length()){
          //finn == eller =
          if(cLine[tell_for_split] == '='){

            boolean ikke_lang_tegn = true;
            if(tell_for_split < line.length()-1){ //to avoid out of bounds error
              if(cLine[tell_for_split +1] == '='){
                ikke_lang_tegn = false;
                curLineTokens.add(new Token(doubleEqualToken,curLineNum()));
                tell_for_split = tell_for_split +2;
              }
            }
            if(ikke_lang_tegn){
              curLineTokens.add(new Token(equalToken,curLineNum()));
              tell_for_split++;
            }
          }
        }
        if(tell_for_split < line.length()){
          //finn // eller /
          if(cLine[tell_for_split] == '/'){
            boolean ikke_lang_tegn = true;
            if(tell_for_split < line.length()-1){ //to avoid out of bounds error
              if(cLine[tell_for_split +1] == '/'){
                ikke_lang_tegn = false;
                curLineTokens.add(new Token(doubleSlashToken,curLineNum()));
                tell_for_split = tell_for_split +2;
              }
            }
            if(ikke_lang_tegn){
              curLineTokens.add(new Token(slashToken,curLineNum()));
              tell_for_split++;
            }
          }
        }

        if(tell_for_split < line.length()){
          //finn > eller >=
          if(cLine[tell_for_split] == '>'){
            boolean ikke_lang_tegn = true;
            if(tell_for_split < line.length()-1){ //to avoid out of bounds error
              if(cLine[tell_for_split +1] == '='){
                ikke_lang_tegn = false;
                curLineTokens.add(new Token(greaterEqualToken,curLineNum()));
                tell_for_split = tell_for_split +2;
              }
          }
          if(ikke_lang_tegn){
              curLineTokens.add(new Token(greaterToken,curLineNum()));
              tell_for_split++;
            }
          }
        }
        if(tell_for_split < line.length()){
          //finn < eller <=
          if(cLine[tell_for_split] == '<'){
            boolean ikke_lang_tegn = true;
            if(tell_for_split < line.length()-1){ //to avoid out of bounds error
              if(cLine[tell_for_split +1] == '='){
                ikke_lang_tegn = false;
                curLineTokens.add(new Token(lessEqualToken,curLineNum()));
                tell_for_split = tell_for_split +2;
              }
            }
            if(ikke_lang_tegn){
              curLineTokens.add(new Token(lessToken,curLineNum()));
              tell_for_split++;
            }
          }
        }
        if(tell_for_split < line.length()){
          //finn -
          if(cLine[tell_for_split] == '-'){
            curLineTokens.add(new Token(minusToken,curLineNum()));
            tell_for_split++;
          }
        }
        if(tell_for_split < cLine.length -1){
          //finn !=

          if(cLine[tell_for_split] == '!' && cLine[tell_for_split +1] == '='){
            curLineTokens.add(new Token(notEqualToken,curLineNum()));
            tell_for_split = tell_for_split +2;
          }
        }

        if(tell_for_split < line.length()){
          //finn %
          if(cLine[tell_for_split] == '%'){
            curLineTokens.add(new Token(percentToken,curLineNum()));
            tell_for_split++;
          }
        }
        if(tell_for_split < line.length()){
          //finn +
          if(cLine[tell_for_split] == '+'){
            curLineTokens.add(new Token(plusToken,curLineNum()));
            tell_for_split++;
          }
        }
        if(tell_for_split < line.length()){
          //finn :
          if(cLine[tell_for_split] == ':'){
            curLineTokens.add(new Token(colonToken,curLineNum()));
            tell_for_split++;
          }
        }
        if(tell_for_split < line.length()){
          //finn ,
          if(cLine[tell_for_split] == ','){
            curLineTokens.add(new Token(commaToken,curLineNum()));
            tell_for_split++;
          }
        }
        if(tell_for_split < line.length()){
          //finn {
          if(cLine[tell_for_split] == '{'){
            curLineTokens.add(new Token(leftBraceToken,curLineNum()));
            tell_for_split++;
          }
        }
        if(tell_for_split < line.length()){
          //finn }
          if(cLine[tell_for_split] == '}'){
            curLineTokens.add(new Token(rightBraceToken,curLineNum()));
            tell_for_split++;
          }
        }
        if(tell_for_split < line.length()){
          //finn [
          if(cLine[tell_for_split] == '['){
            curLineTokens.add(new Token(leftBracketToken,curLineNum()));
            tell_for_split++;
          }
        }
        if(tell_for_split < line.length()){
          //finn ]
          if(cLine[tell_for_split] == ']'){
            curLineTokens.add(new Token(rightBracketToken,curLineNum()));
            tell_for_split++;
          }
        }
        if(tell_for_split < line.length()){
          //finn (
          if(cLine[tell_for_split] == '('){
            curLineTokens.add(new Token(leftParToken,curLineNum()));
            tell_for_split++;
          }
        }
        if(tell_for_split < line.length()){
          //finn )
          if(cLine[tell_for_split] == ')'){
            curLineTokens.add(new Token(rightParToken,curLineNum()));
            tell_for_split++;
          }
        }
        //hvis den trefer # er resten kommentar of stopp lesing
        if(tell_for_split < line.length()){
          if(cLine[tell_for_split] == '#'){
            break;
          }
        }

      }
      // legg til newline token
      curLineTokens.add(new Token(newLineToken,curLineNum()));
    }

  }else{
    //fil er tom avslutt
    while(indents[(numIndents - 1)] > 0){
      curLineTokens.add(new Token(dedentToken,curLineNum()));
      numIndents --;
    }
    curLineTokens.add(new Token(eofToken,curLineNum()));
  }




	// Terminate line:
  //registrer lineTokens til log
	for (Token t: curLineTokens)
	    Main.log.noteToken(t);
    }


    public int curLineNum() {
	return sourceFile!=null ? sourceFile.getLineNumber() : 0;
    }

    private int findIndent(String s) {
	int indent = 0;

	while (indent<s.length() && s.charAt(indent)==' ') indent++;
	return indent;
    }

    private String expandLeadingTabs(String s) {
	String newS = "";
	for (int i = 0;  i < s.length();  i++) {
	    char c = s.charAt(i);
	    if (c == '\t') {
		do {
		    newS += " ";
		} while (newS.length()%tabDist != 0);
	    } else if (c == ' ') {
		newS += " ";
	    } else {
		newS += s.substring(i);
		break;
	    }
	}
	return newS;
    }


    private boolean isLetterAZ(char c) {
	return ('A'<=c && c<='Z') || ('a'<=c && c<='z') || (c=='_');
    }


    private boolean isDigit(char c) {
	return '0'<=c && c<='9';
    }


    public boolean isCompOpr() {
	TokenKind k = curToken().kind;
	if(k == greaterToken || k == lessToken || k == greaterEqualToken || k == lessEqualToken || k == notEqualToken || k == doubleEqualToken) return true;
	return false;
    }


    public boolean isFactorPrefix() {
	TokenKind k = curToken().kind;
	if(k == plusToken || k == minusToken) return true;
	return false;
    }


    public boolean isFactorOpr() {
	TokenKind k = curToken().kind;
	if(k == astToken || k == slashToken || k == percentToken || k == doubleSlashToken) return true;
	return false;
    }


    public boolean isTermOpr() {
	TokenKind k = curToken().kind;
	if(k == plusToken || k == minusToken) return true;
	return false;
    }
}
