package no.uio.ifi.asp.runtime;

import java.util.ArrayList;
import java.util.Scanner;

import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.parser.AspSyntax;

public class RuntimeLibrary extends RuntimeScope {
    private Scanner keyboard = new Scanner(System.in);

    public RuntimeLibrary() {
	//-- Must be changed in part 4:
      // len
      assign("len", new RuntimeFunc("len") {
          @Override
          public RuntimeValue evalFuncCall(ArrayList<RuntimeValue> actualParams, AspSyntax where)throws RuntimeReturnValue {
            checkNumParams(actualParams, 1, "len", where);
            return actualParams.get(0).evalLen(where);
          }});


      // float
      assign("float", new RuntimeFunc("float") {
          @Override
          public RuntimeValue evalFuncCall(ArrayList<RuntimeValue> actualParams, AspSyntax where)throws RuntimeReturnValue {
            checkNumParams(actualParams, 1, "float", where);
            return new RuntimeFloatValue(actualParams.get(0).getFloatValue("float func", where));
          }});


      // int
      assign("int", new RuntimeFunc("int") {
          @Override
          public RuntimeValue evalFuncCall(ArrayList<RuntimeValue> actualParams, AspSyntax where)throws RuntimeReturnValue {
            checkNumParams(actualParams, 1, "int", where);
            return new RuntimeIntValue(actualParams.get(0).getIntValue("int func", where));
          }});


      // str
      assign("str", new RuntimeFunc("str") {
          @Override
          public RuntimeValue evalFuncCall(ArrayList<RuntimeValue> actualParams, AspSyntax where)throws RuntimeReturnValue {
            checkNumParams(actualParams, 1, "str", where);
            return new RuntimeStringValue(actualParams.get(0).toString());
          }});


      //input
      assign("input", new RuntimeFunc("input") {
          @Override
          public RuntimeValue evalFuncCall(ArrayList<RuntimeValue> actualParams, AspSyntax where)throws RuntimeReturnValue {
            checkNumParams(actualParams, 1, "input", where);
            System.out.println(actualParams.get(0).toString());
            String user_in = keyboard.nextLine();
            return new RuntimeStringValue(user_in);
          }});

      //range
      assign("range", new RuntimeFunc("range") {
          @Override
          public RuntimeValue evalFuncCall(ArrayList<RuntimeValue> actualParams, AspSyntax where)throws RuntimeReturnValue {
            checkNumParams(actualParams, 2, "range", where);
            ArrayList<RuntimeValue> tall = new ArrayList<>();
            for (long i = actualParams.get(0).getIntValue("range func", where); i < actualParams.get(1).getIntValue("range func", where); i++) tall.add(new RuntimeIntValue(i));
            return new RuntimeListValue(tall);
          }});

      // print
      assign("print", new RuntimeFunc("print") {
            @Override
            public RuntimeValue evalFuncCall(ArrayList<RuntimeValue> actualParams, AspSyntax where)throws RuntimeReturnValue {
                for (int i = 0; i < actualParams.size(); ++i) {
                    if (i > 0) System.out.print(" ");
                    System.out.print(actualParams.get(i).toString());
                }
                System.out.println();
                return new RuntimeNoneValue();
            }});


    }


    private void checkNumParams(ArrayList<RuntimeValue> actArgs, int nCorrect, String id, AspSyntax where) {
      if (actArgs.size() != nCorrect)
        RuntimeValue.runtimeError("Wrong number of parameters to "+id+"!",where);
    }
}
