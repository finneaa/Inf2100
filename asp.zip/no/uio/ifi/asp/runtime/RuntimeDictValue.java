package no.uio.ifi.asp.runtime;

import java.util.Iterator;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.parser.AspSyntax;

public class RuntimeDictValue extends RuntimeValue {
    HashMap<String, RuntimeValue> dict = new HashMap<String, RuntimeValue>();

    public RuntimeDictValue(ArrayList<String> strLit, ArrayList<RuntimeValue> expr) {
      int nPrinted = 0;
      for (String sv: strLit) {
        dict.put(strLit.get(nPrinted).substring(1,strLit.get(nPrinted).length() -1) , expr.get(nPrinted));
        nPrinted ++;
      }
    }


    @Override
    protected String typeName() {
       return "Dict Display";
    }


    @Override
    public String showInfo() {
      String toStringText = "{";
      Set set = dict.entrySet();
      Iterator iterator = set.iterator();
      while(iterator.hasNext()) {
         Map.Entry mentry = (Map.Entry)iterator.next();
         toStringText = toStringText + mentry.getKey() + " : " + mentry.getValue().toString();
         toStringText = toStringText + ",";
      }
      toStringText = toStringText.substring(0,toStringText.length()-1);
      toStringText = toStringText + "}";
	    return toStringText;
    }


    @Override
    public String toString() {
      String toStringText = "{";
      Set set = dict.entrySet();
      Iterator iterator = set.iterator();
      while(iterator.hasNext()) {
         Map.Entry mentry = (Map.Entry)iterator.next();
         toStringText = toStringText + mentry.getKey() + " : " + mentry.getValue().toString();
         toStringText = toStringText + ",";
      }
      toStringText = toStringText.substring(0,toStringText.length()-1);
      toStringText = toStringText + "}";
	    return toStringText;
    }


    @Override
    public boolean getBoolValue(String what, AspSyntax where) {
      if(dict.isEmpty()){
        return false;
      }
     return true;
    }


    @Override
    public RuntimeValue evalEqual(RuntimeValue v, AspSyntax where) {
    	if (v instanceof RuntimeNoneValue) {
    	    return new RuntimeBoolValue(false);
    	}
    	runtimeError("Type error for ==.", where);
      return null;  // Required by the compiler
    }


    @Override
    public RuntimeValue evalNot(AspSyntax where) {
      if(dict.isEmpty()){
        return new RuntimeBoolValue(true);
      }
     return new RuntimeBoolValue(false);
    }


    @Override
    public RuntimeValue evalNotEqual(RuntimeValue v, AspSyntax where) {
    	if (v instanceof RuntimeNoneValue) {
    	    return new RuntimeBoolValue(true);
    	}
    	runtimeError("Type error for !=.", where);
    	return null;  // Required by the compiler
    }

    @Override
    public RuntimeValue evalSubscription(RuntimeValue v, AspSyntax where) {
      if(v instanceof RuntimeStringValue){
        //System.out.println("inside sub Dict"); // #FR
        //for(String key : dict.keySet()) System.out.println(key); // #FR
        if(dict.containsKey(v.toString())){
          //System.out.println("inside sub Dict hent verdi."); // #FR
          //System.out.println(v.toString()); // #FR
          return dict.get(v.toString());
        }
      }
    	return null;  // Required by the compiler!
    }

    @Override
    public RuntimeValue evalLen(AspSyntax where) {
    	long size = 0;
      for(String key : dict.keySet()){
        size ++;
      }
    	return new RuntimeIntValue(size);
    }

    @Override
    public void evalAssignElem(RuntimeValue inx, RuntimeValue val, AspSyntax where) {
      dict.put(inx.toString(),val);
    }
}
