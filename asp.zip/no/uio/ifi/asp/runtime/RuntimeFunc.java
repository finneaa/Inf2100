package no.uio.ifi.asp.runtime;

import java.util.*;
import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.parser.*;
import java.lang.Math;

public class RuntimeFunc extends RuntimeValue{
    AspFuncDef def;
    RuntimeScope defScope;
    String name;

    public RuntimeFunc(String name){
      this.name = name;
    }

    public RuntimeFunc(String name, RuntimeScope defScope, AspFuncDef def){
      this.name = name;
      this.def = def;
      this.defScope = defScope;
    }


    @Override
    protected String typeName() {
       return "Func Def";
    }


    @Override
    public String toString() {
	     return name;
    }


    @Override
    public RuntimeValue evalFuncCall(ArrayList<RuntimeValue> actualParams, AspSyntax where)throws RuntimeReturnValue{


      //Sjekk korrekt antall parameterer
      if(actualParams.size() == (def.names.size() -1)){
        RuntimeScope nyttScope = new RuntimeScope(defScope);
        for(int i = 1; i < def.names.size();i ++){
        nyttScope.assign(def.names.get(i).nameValue , actualParams.get(i-1));
        }
        return runFunction(nyttScope);
      }
      runtimeError("Function call does not have correct amount of parameters or actuel and formal parameters is not right", where);
      return null;
    }


    public RuntimeValue runFunction(RuntimeScope curScope) throws RuntimeReturnValue{
      try {
        def.body.eval(curScope);
      } catch (RuntimeReturnValue rrv) {
        return rrv.value;
      }
      return new RuntimeNoneValue();
    }
}
