package no.uio.ifi.asp.runtime;

import java.util.ArrayList;
import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.parser.AspSyntax;

public class RuntimeListValue extends RuntimeValue {
    public ArrayList<RuntimeValue> exprs;

    public RuntimeListValue(ArrayList<RuntimeValue> expr) {
	     exprs = new ArrayList<>(expr);
    }


    @Override
    public String showInfo() {
      String toStringText = "[";
      if(exprs.isEmpty()){
        toStringText = toStringText + "]";
        return toStringText;
      }
      for(RuntimeValue rv : exprs){
        toStringText = toStringText + rv.showInfo() + ",";
      }
      toStringText = toStringText.substring(0,toStringText.length()-1);
      toStringText = toStringText + "]";
      return toStringText;
    }



    @Override
    protected String typeName() {
       return "List Display";
    }


    @Override
    public String toString() {
      String toStringText = "[";
      if(exprs.isEmpty()){
        toStringText = toStringText + "]";
        return toStringText;
      }
      for(RuntimeValue rv : exprs){
        toStringText = toStringText + rv.toString() + ",";
      }
      toStringText = toStringText.substring(0,toStringText.length()-1);
      toStringText = toStringText + "]";
      return toStringText;
    }


    @Override
    public boolean getBoolValue(String what, AspSyntax where) {
      if(exprs.isEmpty()){
        return false;
      }
     return true;
    }


    @Override
    public RuntimeValue evalMultiply(RuntimeValue v, AspSyntax where) {
      if (v instanceof RuntimeIntValue){
        long antallcopi = v.getIntValue("* operand",where);
        ArrayList<RuntimeValue> multiList = new ArrayList<>();
        for(long tel = 0; tel < antallcopi;tel ++){
          for(RuntimeValue rv : exprs){
            multiList.add(rv);
          }
        }
        return new RuntimeListValue(multiList);
      }
    	runtimeError("Type error for *.", where);
    	return null;  // Required by the compiler!
    }


    @Override
    public RuntimeValue evalEqual(RuntimeValue v, AspSyntax where) {
    	if (v instanceof RuntimeNoneValue) {
    	    return new RuntimeBoolValue(false);
    	}
    	runtimeError("Type error for ==.", where);
      return null;  // Required by the compiler
    }


    @Override
    public RuntimeValue evalNot(AspSyntax where) {
      if(exprs.isEmpty()){
        return new RuntimeBoolValue(true);
      }
     return new RuntimeBoolValue(false);
    }


    @Override
    public RuntimeValue evalNotEqual(RuntimeValue v, AspSyntax where) {
    	if (v instanceof RuntimeNoneValue) {
    	    return new RuntimeBoolValue(true);
    	}
    	runtimeError("Type error for !=.", where);
    	return null;  // Required by the compiler
    }


    @Override
    public RuntimeValue evalSubscription(RuntimeValue v, AspSyntax where) {
      if(v instanceof RuntimeIntValue){
        //System.out.println("inside sub list"); // #FR
        if(v.getIntValue("for subscription list", where) >= 0 && v.getIntValue("for subscription list", where) < exprs.size()){
          //System.out.println("inside sub list hent verdi."); // #FR
          //System.out.println((int) v.getIntValue("for subscription", where)); // #FR
          return exprs.get((int) v.getIntValue("for subscription list", where));
        }
      }
    	return null;  // Required by the compiler!
    }


    @Override
    public RuntimeValue evalLen(AspSyntax where) {
    	long size = 0;
      for(RuntimeValue key : exprs){
        size ++;
      }
    	return new RuntimeIntValue(size);
    }


    @Override
    public void evalAssignElem(RuntimeValue inx, RuntimeValue val, AspSyntax where) {
       if(inx.getIntValue("list assignElem",where) >= 0 && inx.getIntValue("list assignElem",where) < exprs.size()){
         exprs.add((int)inx.getIntValue("list assignElem",where), val);
       }
    }

}
