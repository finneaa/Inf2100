package no.uio.ifi.asp.runtime;

import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.parser.AspSyntax;

public class RuntimeStringValue extends RuntimeValue {
    String strValue;

    public RuntimeStringValue(String v) {
    strValue = v;
    }


    @Override
    public String showInfo() {
      if (strValue.indexOf('\'') >= 0){
        return '"' + strValue + '"';
      }else{
        return "'" + strValue + "'";
      }
    }



    @Override
    protected String typeName() {
       return "String";
    }


    @Override
    public String toString() {
	     return strValue;
    }


    @Override
    public String getStringValue(String what, AspSyntax where) {
    	return strValue;
    }


    @Override
    public boolean getBoolValue(String what, AspSyntax where) {
    	if(strValue.equals("")){
        return false;
      }
    	return true;
    }

    public double getFloatValue(String what, AspSyntax where) throws NumberFormatException {
      try {
        return Double.parseDouble(strValue);
      } catch (NumberFormatException e) {
        runtimeError("String "+strValue+" can not be converted to a Float! happend in: "+ what, where);
      }
    	return 0.0;  // Required by the compiler!
    }

    public long getIntValue(String what, AspSyntax where) throws NumberFormatException {
      try {
        return Long.parseLong(strValue);
      } catch (NumberFormatException e) {
        runtimeError("String "+strValue+" can not be converted to a integer! happend in: "+ what, where);
      }
    	return 0;  // Required by the compiler!
    }

    @Override
    public RuntimeValue evalAdd(RuntimeValue v, AspSyntax where) {
      if (v instanceof RuntimeStringValue) {
        return new RuntimeStringValue(strValue + v.getStringValue("+ operand",where));
      }
      runtimeError("Type error for +.", where);
      return null; // Required by the compiler.
    }


    @Override
    public RuntimeValue evalGreater(RuntimeValue v, AspSyntax where) {
      if (v instanceof RuntimeStringValue) {
        if(strValue.length() > v.getStringValue("> operand",where).length()){
          return new RuntimeBoolValue(true);
        }
        return new RuntimeBoolValue(false);
      }
      runtimeError("Type error for >.", where);
    	return null;  // Required by the compiler!
    }


    @Override
    public RuntimeValue evalGreaterEqual(RuntimeValue v, AspSyntax where) {
      if (v instanceof RuntimeStringValue) {
        if(strValue.length() >= v.getStringValue(">= operand",where).length()){
          return new RuntimeBoolValue(true);
        }
        return new RuntimeBoolValue(false);
      }
      runtimeError("Type error for >=.", where);
    	return null;  // Required by the compiler!
    }


    @Override
    public RuntimeValue evalLess(RuntimeValue v, AspSyntax where) {
      if (v instanceof RuntimeStringValue) {
        if(strValue.length() < v.getStringValue("< operand",where).length()){
          return new RuntimeBoolValue(true);
        }
        return new RuntimeBoolValue(false);
      }
      runtimeError("Type error for <.", where);
    	return null;  // Required by the compiler!
    }


    @Override
    public RuntimeValue evalLessEqual(RuntimeValue v, AspSyntax where) {
      if (v instanceof RuntimeStringValue) {
        if(strValue.length() <= v.getStringValue("<= operand",where).length()){
          return new RuntimeBoolValue(true);
        }
        return new RuntimeBoolValue(false);
      }
      runtimeError("Type error for <=.", where);
    	return null;  // Required by the compiler!
    }


    @Override
    public RuntimeValue evalMultiply(RuntimeValue v, AspSyntax where) {
      if (v instanceof RuntimeIntValue){
        long antallcopi = v.getIntValue("* operand",where);
        String fullstring = "";
        for(long tel = 0; tel < antallcopi;tel ++){
          fullstring = fullstring + strValue;
        }
        return new RuntimeStringValue(fullstring);
      }
    	runtimeError("Type error for *.", where);
    	return null;  // Required by the compiler!
    }


    @Override
    public RuntimeValue evalEqual(RuntimeValue v, AspSyntax where) {
    	if (v instanceof RuntimeStringValue) {
        if(strValue.equals(v.getStringValue("== operand",where))){
          return new RuntimeBoolValue(true);
        }
  	    return new RuntimeBoolValue(false);
    	}else if (v instanceof RuntimeFloatValue) {
        if(strValue.equals(v.toString())){
          return new RuntimeBoolValue(true);
        }
        return new RuntimeBoolValue(false);
      }else if (v instanceof RuntimeIntValue) {
        if(strValue.equals(v.toString())){
          return new RuntimeBoolValue(true);
        }
        return new RuntimeBoolValue(false);
      }else if (v instanceof RuntimeNoneValue) {
        return new RuntimeBoolValue(false);
      }
    	runtimeError("Type error for ==.", where);
      return null;  // Required by the compiler
    }


    @Override
    public RuntimeValue evalNotEqual(RuntimeValue v, AspSyntax where) {
      if (v instanceof RuntimeStringValue) {
        if(strValue.equals(v.getStringValue("!= operand",where))){
          return new RuntimeBoolValue(false);
        }
  	    return new RuntimeBoolValue(true);
    	}else if (v instanceof RuntimeFloatValue) {
        if(strValue.equals(v.toString())){
          return new RuntimeBoolValue(false);
        }
        return new RuntimeBoolValue(true);
      }else if (v instanceof RuntimeIntValue) {
        if(strValue.equals(v.toString())){
          return new RuntimeBoolValue(false);
        }
        return new RuntimeBoolValue(true);
      }else if (v instanceof RuntimeNoneValue) {
        return new RuntimeBoolValue(true);
      }
    	runtimeError("Type error for !=.", where);
    	return null;  // Required by the compiler
    }


    @Override
    public RuntimeValue evalNot(AspSyntax where) {
      if(strValue == ""){
        return new RuntimeBoolValue(true);
      }
    	return new RuntimeBoolValue(false);
    }


    @Override
    public RuntimeValue evalSubscription(RuntimeValue v, AspSyntax where) {
      if(v instanceof RuntimeIntValue){
        //System.out.println("inside sub string"); // #FR
        if(v.getIntValue("for subscription String", where) >= 0 && v.getIntValue("for subscription String", where) < strValue.length()){
          //System.out.println("inside sub string hent verdi."); // #FR
          //System.out.println(String.valueOf(strValue.charAt((int) v.getIntValue("for subscription", where)))); // #FR
          return new RuntimeStringValue(String.valueOf(strValue.charAt((int) v.getIntValue("for subscription String", where))));
        }
      }
    	return null;  // Required by the compiler!
    }

    @Override
    public RuntimeValue evalLen(AspSyntax where) {
    	long size = (long)strValue.length();

    	return new RuntimeIntValue(size);
    }

}
