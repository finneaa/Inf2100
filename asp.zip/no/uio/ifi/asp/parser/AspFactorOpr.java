package no.uio.ifi.asp.parser;
import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.runtime.*;
import no.uio.ifi.asp.scanner.*;
import static no.uio.ifi.asp.scanner.TokenKind.*;

public class AspFactorOpr extends AspSyntax {
  int whatTokenType = 0;
  TokenKind kind;

  AspFactorOpr(int n) {
    super(n);
  }

  public static AspFactorOpr parse(Scanner s) {
    enterParser("factor opr");

    //-- Must be changed in part 2:
    AspFactorOpr afo = new AspFactorOpr(s.curLineNum());
    switch (s.curToken().kind) {
      case astToken:
        afo.kind = s.curToken().kind; s.readNextToken(); afo.whatTokenType = 1; break;
      case percentToken:
        afo.kind = s.curToken().kind; s.readNextToken(); afo.whatTokenType = 2; break;
      case slashToken:
        afo.kind = s.curToken().kind; s.readNextToken(); afo.whatTokenType = 3; break;
      case doubleSlashToken:
        afo.kind = s.curToken().kind; s.readNextToken(); afo.whatTokenType = 4; break;
      default:
        parserError("Expected an expression factor opr but found a " + s.curToken().kind + "!", s.curLineNum());
    }

    leaveParser("factor opr");
    return afo;
  }


  @Override
  public void prettyPrint() {
    //-- Must be changed in part 2:
    if(whatTokenType == 1){
      Main.log.prettyWrite(" * ");
    }else if(whatTokenType == 2){
      Main.log.prettyWrite(" % ");
    }else if(whatTokenType == 3){
      Main.log.prettyWrite(" / ");
    }else if(whatTokenType == 4){
      Main.log.prettyWrite(" // ");
    }
  }


  @Override
  public RuntimeValue eval(RuntimeScope curScope) throws RuntimeReturnValue {
    //-- Must be changed in part 3:
    return null;
  }
}
