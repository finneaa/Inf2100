package no.uio.ifi.asp.parser;
import java.util.ArrayList;

import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.runtime.*;
import no.uio.ifi.asp.scanner.*;
import static no.uio.ifi.asp.scanner.TokenKind.*;

public class AspForStmt extends AspStmt {
  AspName aName;
  AspExpr body;
  AspSuite aSuite;

  AspForStmt(int n) {
    super(n);
  }

  public static AspForStmt parse(Scanner s) {
    enterParser("for stmt");

    //-- Must be changed in part 2:
    AspForStmt afs = new AspForStmt(s.curLineNum());
    skip(s,forToken);
    afs.aName = AspName.parse(s);
    skip(s,inToken);
    afs.body = AspExpr.parse(s);
    skip(s,colonToken);
    afs.aSuite = AspSuite.parse(s);

    leaveParser("for stmt");
    return afs;
  }


  @Override
  public void prettyPrint() {
    //-- Must be changed in part 2:
    Main.log.prettyWrite(" for ");
    aName.prettyPrint();
    Main.log.prettyWrite(" in ");
    body.prettyPrint();
    Main.log.prettyWrite(" : ");
    aSuite.prettyPrint();
  }


  @Override
  public RuntimeValue eval(RuntimeScope curScope) throws RuntimeReturnValue {
    //-- Must be changed in part 4:
    RuntimeValue v = body.eval(curScope);
    if(v instanceof RuntimeListValue){ //body instanceof AspListDisplay
      RuntimeListValue w = (RuntimeListValue) v;
      int alt = 1;
      for( RuntimeValue element : w.exprs){ //feil med v.exprs
        // assign to variable name aName
        curScope.assign(aName.nameValue , element);
        trace("for #" + alt +": "+ aName.nameValue + " = " + element.showInfo());
        aSuite.eval(curScope);
        alt++;
      }
    }

    return null;
  }
}
