package no.uio.ifi.asp.parser;
import java.util.ArrayList;

import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.runtime.*;
import no.uio.ifi.asp.scanner.*;
import static no.uio.ifi.asp.scanner.TokenKind.*;

public class AspIfStmt extends AspStmt {
  ArrayList<AspExpr> exprs = new ArrayList<>();
  ArrayList<AspSuite> suites = new ArrayList<>();

  AspIfStmt(int n) {
    super(n);
  }

  public static AspIfStmt parse(Scanner s) {
    enterParser("if stmt");

    //-- Must be changed in part 2:
    AspIfStmt aif = new AspIfStmt(s.curLineNum());
    skip(s,ifToken);
    while(true){
      aif.exprs.add(AspExpr.parse(s));
      skip(s,colonToken);
      aif.suites.add(AspSuite.parse(s));
      if (s.curToken().kind != elifToken) break;
      skip(s, elifToken);
    }
    if(s.curToken().kind == elseToken){
      skip(s,elseToken);
      skip(s,colonToken);
      aif.suites.add(AspSuite.parse(s));
    }

    leaveParser("if stmt");
    return aif;
  }


  @Override
  public void prettyPrint() {
    //-- Must be changed in part 2:
    Main.log.prettyWrite(" if ");
    for (int nPrinted = 0; nPrinted < exprs.size();nPrinted ++) {
      if (nPrinted > 0){
        Main.log.prettyWrite(" elif ");
      }
      exprs.get(nPrinted).prettyPrint();
      Main.log.prettyWrite(" : ");
      suites.get(nPrinted).prettyPrint();
    }
    if(exprs.size() < suites.size()){
      Main.log.prettyWrite(" else : ");
      suites.get((suites.size() -1)).prettyPrint();
    }
  }


  @Override
  public RuntimeValue eval(RuntimeScope curScope) throws RuntimeReturnValue {
    //-- Must be changed in part 4:
    int n_iter = 0;
    boolean done = false;
    for(AspExpr values : exprs){
      int alt = n_iter+1;
      RuntimeValue v = values.eval(curScope);
      if(v.getBoolValue("if-stmt", this) == true){
        trace("if True alt #" + alt +" ...");
        suites.get(n_iter).eval(curScope);
        done = true;
        break;
      }
      n_iter ++;
    }
    if(exprs.size() < suites.size() && done == false){
      trace("else ...");
      suites.get(n_iter).eval(curScope);
    }
    return null; //for compiler
  }
}
