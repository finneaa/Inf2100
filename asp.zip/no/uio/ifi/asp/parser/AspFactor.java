package no.uio.ifi.asp.parser;
import java.util.ArrayList;

import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.runtime.*;
import no.uio.ifi.asp.scanner.*;
import static no.uio.ifi.asp.scanner.TokenKind.*;

public class AspFactor extends AspSyntax {
  ArrayList<AspFactorPrefix> factorPrefixs = new ArrayList<>();
  ArrayList<AspPrimary> primarys = new ArrayList<>();
  ArrayList<AspFactorOpr> factorOprs = new ArrayList<>();
  ArrayList<Integer> factorPrefixPos = new ArrayList<>();

  AspFactor(int n) {
    super(n);
  }

  public static AspFactor parse(Scanner s) {
    enterParser("factor");
    int teller = 0;
    //-- Must be changed in part 2:
    AspFactor af = new AspFactor(s.curLineNum());
    while(true){
      if(s.isFactorPrefix()){
        af.factorPrefixs.add(AspFactorPrefix.parse(s));
        af.factorPrefixPos.add(teller);
      }
      af.primarys.add(AspPrimary.parse(s));
      if (s.isFactorOpr() == false) break;
      af.factorOprs.add(AspFactorOpr.parse(s));
      teller ++;
    }

    leaveParser("factor");
    return af;
  }


  @Override
  public void prettyPrint() {
    //-- Must be changed in part 2:
    int nPrinted = 0;
    int prefixTeller = 0;
    for (AspPrimary ap: primarys) {
      if (nPrinted > 0){
        factorOprs.get(nPrinted -1).prettyPrint();
      }
      if(factorPrefixPos.contains(nPrinted)){
        factorPrefixs.get(prefixTeller).prettyPrint();
        prefixTeller ++;
      }
      ap.prettyPrint();
      nPrinted ++;
    }
  }


  @Override
  public RuntimeValue eval(RuntimeScope curScope) throws RuntimeReturnValue {
    //-- Must be changed in part 3:
    int prefixTel = 0;
    RuntimeValue v = primarys.get(0).eval(curScope);
    if(factorPrefixPos.contains(0)) {
      TokenKind kin = factorPrefixs.get(prefixTel).kind;
      switch (kin) {
        case minusToken:
          v = v.evalNegate(this); prefixTel ++; break;
        case plusToken:
          v = v.evalPositive(this); prefixTel ++; break;
        default:
          Main.panic("Illegal factor prefix: " + kin + "!");
      }
    }

    for (int i = 1; i < primarys.size(); ++i) {
      RuntimeValue t = primarys.get(i).eval(curScope);
      if(factorPrefixPos.contains(i)) {
        TokenKind ki = factorPrefixs.get(prefixTel).kind;
        switch (ki) {
          case minusToken:
            t = t.evalNegate(this); prefixTel ++; break;
          case plusToken:
            t = t.evalPositive(this); prefixTel ++; break;
          default:
            Main.panic("Illegal factor prefix: " + ki + "!");
        }
      }
      TokenKind k = factorOprs.get(i-1).kind;
      switch (k) {
        case astToken:
          v = v.evalMultiply(t, this); break;
        case slashToken:
          v = v.evalDivide(t, this); break;
        case percentToken:
          v = v.evalModulo(t, this); break;
        case doubleSlashToken:
          v = v.evalIntDivide(t, this); break;
        default:
          Main.panic("Illegal factor operator: " + k + "!");
      }
    }
    return v;
  }
}
