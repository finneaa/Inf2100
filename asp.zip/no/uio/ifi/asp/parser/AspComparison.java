package no.uio.ifi.asp.parser;
import java.util.ArrayList;

import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.runtime.*;
import no.uio.ifi.asp.scanner.*;
import static no.uio.ifi.asp.scanner.TokenKind.*;

public class AspComparison extends AspSyntax {
  ArrayList<AspTerm> terms = new ArrayList<>();
  ArrayList<AspCompOpr> compOprs = new ArrayList<>();

  AspComparison(int n) {
    super(n);
  }

  public static AspComparison parse(Scanner s) {
    enterParser("comparison");

    //-- Must be changed in part 2:
    AspComparison ac = new AspComparison(s.curLineNum());
    while(true){
      ac.terms.add(AspTerm.parse(s));
      if (s.isCompOpr() == false) break;
      ac.compOprs.add(AspCompOpr.parse(s));
    }

    leaveParser("comparison");
    return ac;
  }


  @Override
  public void prettyPrint() {
    //-- Must be changed in part 2:
    int nPrinted = 0;
    for (AspTerm at: terms) {
      if (nPrinted > 0){
        compOprs.get(nPrinted -1).prettyPrint();
      }
      at.prettyPrint(); ++nPrinted;
    }
  }


  @Override
  public RuntimeValue eval(RuntimeScope curScope) throws RuntimeReturnValue {
    //-- Must be changed in part 3:
    RuntimeValue lastRTV = terms.get(0).eval(curScope);
    RuntimeValue v = lastRTV;
    boolean null_Feil = true;
    for (int i = 1; i < terms.size(); ++i) {
      TokenKind k = compOprs.get(i-1).kind;
      switch (k) {
        case lessToken:
          v = lastRTV.evalLess(terms.get(i).eval(curScope), this); break;
        case lessEqualToken:
          v = lastRTV.evalLessEqual(terms.get(i).eval(curScope), this);break;
        case greaterToken:
          v = lastRTV.evalGreater(terms.get(i).eval(curScope), this);break;
        case greaterEqualToken:
          v = lastRTV.evalGreaterEqual(terms.get(i).eval(curScope), this); break;
        case doubleEqualToken:
          v = lastRTV.evalEqual(terms.get(i).eval(curScope), this);break;
        case notEqualToken:
          v = lastRTV.evalNotEqual(terms.get(i).eval(curScope), this);break;
        default:
          Main.panic("Illegal comp operator: " + k + "!");
      }
      lastRTV = terms.get(i).eval(curScope);
      if(v.getBoolValue("comp operator", this) == false) null_Feil = false;
    }
    if(!null_Feil) return new RuntimeBoolValue(false);
    return v;
  }
}
