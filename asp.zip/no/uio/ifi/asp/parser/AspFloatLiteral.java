package no.uio.ifi.asp.parser;
import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.runtime.*;
import no.uio.ifi.asp.scanner.*;
import static no.uio.ifi.asp.scanner.TokenKind.*;

public class AspFloatLiteral extends AspAtom {
  double floatValue = 0.0;

  AspFloatLiteral(int n) {
    super(n);
  }

  public static AspFloatLiteral parse(Scanner s) {
    enterParser("float literal");

    //-- Must be changed in part 2:
    AspFloatLiteral afl = new AspFloatLiteral(s.curLineNum());
    afl.floatValue = s.curToken().floatLit;
    skip(s, floatToken);

    leaveParser("float literal");
    return afl;
  }


  @Override
  public void prettyPrint() {
    //-- Must be changed in part 2:
    Main.log.prettyWrite(Double.toString(floatValue));
  }


  @Override
  public RuntimeValue eval(RuntimeScope curScope) throws RuntimeReturnValue {
    //-- Must be changed in part 3:
    return new RuntimeFloatValue(floatValue);
  }
}
