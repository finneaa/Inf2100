package no.uio.ifi.asp.parser;
import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.runtime.*;
import no.uio.ifi.asp.scanner.*;
import static no.uio.ifi.asp.scanner.TokenKind.*;

public abstract class AspStmt extends AspSyntax {

  AspStmt(int n) {
    super(n);
  }

  public static AspStmt parse(Scanner s) {
    enterParser("stmt");

    //-- Must be changed in part 2:
    AspStmt as = null;
    if(s.curToken().kind == forToken){
      as = AspForStmt.parse(s);
    }else if(s.curToken().kind == ifToken){
      as = AspIfStmt.parse(s);
    }else if(s.curToken().kind == whileToken){
      as = AspWhileStmt.parse(s);
    }else if(s.curToken().kind == returnToken){
      as = AspReturnStmt.parse(s);
    }else if(s.curToken().kind == passToken){
      as = AspPassStmt.parse(s);
    }else if(s.curToken().kind == defToken){
      as = AspFuncDef.parse(s);
    }else if(s.anyEqualToken()){ //assignment
      as = AspAssignment.parse(s);
    }else{ //expr stmt
      as = AspExprStmt.parse(s);
    }

    leaveParser("stmt");
    return as;
  }

}
