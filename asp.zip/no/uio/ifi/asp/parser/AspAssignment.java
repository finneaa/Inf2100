package no.uio.ifi.asp.parser;
import java.util.ArrayList;

import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.runtime.*;
import no.uio.ifi.asp.scanner.*;
import static no.uio.ifi.asp.scanner.TokenKind.*;

public class AspAssignment extends AspStmt {
  AspName aName;
  AspExpr aExpr;
  ArrayList<AspSubscription> subs = new ArrayList<>();

  AspAssignment(int n) {
    super(n);
  }

  public static AspAssignment parse(Scanner s) {
    enterParser("assignment");

    //-- Must be changed in part 2:
    AspAssignment aa = new AspAssignment(s.curLineNum());
    aa.aName = AspName.parse(s);
    while(true){
      if (s.curToken().kind == equalToken) break;
      aa.subs.add(AspSubscription.parse(s));
    }
    skip(s, equalToken);
    aa.aExpr = AspExpr.parse(s);
    skip(s, newLineToken);

    leaveParser("assignment");
    return aa;
  }


  @Override
  public void prettyPrint() {
    //-- Must be changed in part 2:
    aName.prettyPrint();
    for (AspSubscription as: subs) {
      as.prettyPrint();
    }
    Main.log.prettyWrite(" = ");
    aExpr.prettyPrint();
    Main.log.prettyWriteLn();
  }


  @Override
  public RuntimeValue eval(RuntimeScope curScope) throws RuntimeReturnValue {
    //-- Must be changed in part 4:
    RuntimeValue vvv =  aExpr.eval(curScope);
    if(subs.isEmpty() == false){
      RuntimeValue v = aName.eval(curScope);
      int n_iter = 1;
      String for_trace = aName.nameValue;
      //if its a list/tabell forloop starts
      for(AspSubscription as: subs){
        RuntimeValue vv = as.eval(curScope);
        if(n_iter < subs.size()){
          v = v.evalSubscription(vv, this);
          for_trace +="["+ vv.toString() + "]";
        }else{
          for_trace +="["+ vv.toString() + "] = " + vvv.showInfo();
          trace(for_trace);
          v.evalAssignElem(vv, vvv, this);
          return null;
        }
        n_iter++;
      }
    }
    //not list or tabell
    curScope.assign(aName.nameValue, vvv);
    trace(aName.nameValue + " = " + vvv.showInfo());
    return null;
  }
}
