package no.uio.ifi.asp.parser;
import java.util.ArrayList;

import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.runtime.*;
import no.uio.ifi.asp.scanner.*;
import static no.uio.ifi.asp.scanner.TokenKind.*;

public class AspSuite extends AspSyntax {
  ArrayList<AspStmt> stmts = new ArrayList<>();

  AspSuite(int n) {
    super(n);
  }

  public static AspSuite parse(Scanner s) {
    enterParser("suite");

    //-- Must be changed in part 2:
    AspSuite as = new AspSuite(s.curLineNum());
    skip(s, newLineToken);
    skip(s, indentToken);
    while(true){
      as.stmts.add(AspStmt.parse(s));
      if (s.curToken().kind == dedentToken) break;
    }
    skip(s, dedentToken);

    leaveParser("suite");
    return as;
  }


  @Override
  public void prettyPrint() {
    //-- Must be changed in part 2:
    Main.log.prettyWriteLn();
    Main.log.prettyIndent();
    for (AspStmt as: stmts) {
      as.prettyPrint();
    }
    Main.log.prettyDedent();
  }


  @Override
  public RuntimeValue eval(RuntimeScope curScope) throws RuntimeReturnValue {
    //-- Must be changed in part 4:
      for(AspStmt stmt : stmts){
        stmt.eval(curScope);
      }
    return null;
  }
}
