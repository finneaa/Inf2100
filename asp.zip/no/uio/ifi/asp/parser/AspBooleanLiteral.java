package no.uio.ifi.asp.parser;
import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.runtime.*;
import no.uio.ifi.asp.scanner.*;
import static no.uio.ifi.asp.scanner.TokenKind.*;

public class AspBooleanLiteral extends AspAtom {
  boolean verdi = false;

  AspBooleanLiteral(int n) {
    super(n);
  }

  public static AspBooleanLiteral parse(Scanner s) {
    enterParser("boolean literal");

    //-- Must be changed in part 2:
    AspBooleanLiteral abl = new AspBooleanLiteral(s.curLineNum());
    test(s, falseToken,trueToken);
    if (s.curToken().kind == trueToken) abl.verdi = true;
  	s.readNextToken();

    leaveParser("boolean literal");
    return abl;
  }


  @Override
  public void prettyPrint() {
    //-- Must be changed in part 2:
    if(verdi) {
      Main.log.prettyWrite("true");
    }else{
      Main.log.prettyWrite("false");
    }
  }


  @Override
  public RuntimeValue eval(RuntimeScope curScope) throws RuntimeReturnValue {
    //-- Must be changed in part 3:
    return new RuntimeBoolValue(verdi);
  }
}
