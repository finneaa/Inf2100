package no.uio.ifi.asp.parser;
import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.runtime.*;
import no.uio.ifi.asp.scanner.*;
import static no.uio.ifi.asp.scanner.TokenKind.*;

public class AspCompOpr extends AspSyntax {
  int whatTokenType = 0;
  TokenKind kind;
  AspCompOpr(int n) {
    super(n);
  }

  public static AspCompOpr parse(Scanner s) {
    enterParser("comp opr");

    //-- Must be changed in part 2:
    AspCompOpr aco = new AspCompOpr(s.curLineNum());
    switch (s.curToken().kind) {
      case greaterToken:
        aco.kind = s.curToken().kind; s.readNextToken(); aco.whatTokenType = 1; break;
      case greaterEqualToken:
        aco.kind = s.curToken().kind; s.readNextToken(); aco.whatTokenType = 2; break;
      case lessToken:
        aco.kind = s.curToken().kind; s.readNextToken(); aco.whatTokenType = 3; break;
      case lessEqualToken:
        aco.kind = s.curToken().kind; s.readNextToken(); aco.whatTokenType = 4; break;
      case notEqualToken:
        aco.kind = s.curToken().kind; s.readNextToken(); aco.whatTokenType = 5; break;
      case doubleEqualToken:
        aco.kind = s.curToken().kind; s.readNextToken(); aco.whatTokenType = 6; break;
      default:
        parserError("Expected an expression comp opr but found a " + s.curToken().kind + "!", s.curLineNum());
    }

    leaveParser("comp opr");
    return aco;
  }


  @Override
  public void prettyPrint() {
    //-- Must be changed in part 2:
    if(whatTokenType == 1){
      Main.log.prettyWrite(" > ");
    }else if(whatTokenType == 2){
      Main.log.prettyWrite(" >= ");
    }else if(whatTokenType == 3){
      Main.log.prettyWrite(" < ");
    }else if(whatTokenType == 4){
      Main.log.prettyWrite(" <= ");
    }else if(whatTokenType == 5){
      Main.log.prettyWrite(" != ");
    }else if(whatTokenType == 6){
      Main.log.prettyWrite(" == ");
    }
  }


  @Override
  public RuntimeValue eval(RuntimeScope curScope) throws RuntimeReturnValue {
    //-- Must be changed in part 3:
    return null;
  }
}
