package no.uio.ifi.asp.parser;
import java.util.ArrayList;

import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.runtime.*;
import no.uio.ifi.asp.scanner.*;
import static no.uio.ifi.asp.scanner.TokenKind.*;

public class AspDictDisplay extends AspAtom {
  ArrayList<AspStringLiteral> stringLiterals = new ArrayList<>();
  ArrayList<AspExpr> exprs = new ArrayList<>();

  AspDictDisplay(int n) {
    super(n);
  }

  public static AspDictDisplay parse(Scanner s) {
    enterParser("dict display ");

    //-- Must be changed in part 2:
    AspDictDisplay aDD = new AspDictDisplay(s.curLineNum());
    skip(s, leftBraceToken);
    while(true){
      if (s.curToken().kind != stringToken) break;
      aDD.stringLiterals.add(AspStringLiteral.parse(s));
      skip(s, colonToken);
      aDD.exprs.add(AspExpr.parse(s));
      if (s.curToken().kind != commaToken) break;
      skip(s, commaToken);
    }
    skip(s,rightBraceToken);

    leaveParser("dict display");
    return aDD;
  }


  @Override
  public void prettyPrint() {
    //-- Must be changed in part 2:
    Main.log.prettyWrite(" { ");
    int nPrinted = 0;
    for (AspStringLiteral asl: stringLiterals) {
      if (nPrinted > 0){
        Main.log.prettyWrite(", ");
      }
      asl.prettyPrint();
      Main.log.prettyWrite(" : ");
      exprs.get(nPrinted).prettyPrint();
      nPrinted ++;
    }
    Main.log.prettyWrite(" } ");
  }


  @Override
  public RuntimeValue eval(RuntimeScope curScope) throws RuntimeReturnValue {
    //-- Must be changed in part 3:
    ArrayList<String> runStringLiterals = new ArrayList<>();
    ArrayList<RuntimeValue> runExprs = new ArrayList<>();
    int nPrinted = 0;
    for (AspStringLiteral asl: stringLiterals) {
      runStringLiterals.add(asl.text);
      runExprs.add(exprs.get(nPrinted).eval(curScope));
      nPrinted ++;
    }
    return new RuntimeDictValue(runStringLiterals, runExprs);
  }
}
