package no.uio.ifi.asp.parser;
import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.runtime.*;
import no.uio.ifi.asp.scanner.*;
import static no.uio.ifi.asp.scanner.TokenKind.*;

public class AspExprStmt extends AspStmt {
  AspExpr body;

  AspExprStmt(int n) {
    super(n);
  }

  public static AspExprStmt parse(Scanner s) {
    enterParser("expr stmt");

    //-- Must be changed in part 2:
    AspExprStmt aes = new AspExprStmt(s.curLineNum());
    aes.body = AspExpr.parse(s);
    skip(s, newLineToken);

    leaveParser("expr stmt");
    return aes;
  }


  @Override
  public void prettyPrint() {
    //-- Must be changed in part 2:
    body.prettyPrint();
    Main.log.prettyWriteLn();
  }


  @Override
  public RuntimeValue eval(RuntimeScope curScope) throws RuntimeReturnValue {
    //-- Must be changed in part 3:
    RuntimeValue v = body.eval(curScope);
    return v;
  }
}
