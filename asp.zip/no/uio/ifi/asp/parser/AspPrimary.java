package no.uio.ifi.asp.parser;
import java.util.ArrayList;

import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.runtime.*;
import no.uio.ifi.asp.scanner.*;
import static no.uio.ifi.asp.scanner.TokenKind.*;

public class AspPrimary extends AspSyntax {
  ArrayList<AspPrimarySuffix> primarySuffixs = new ArrayList<>();
  AspAtom body;

  AspPrimary(int n) {
    super(n);
  }

  public static AspPrimary parse(Scanner s) {
    enterParser("primary");

    //-- Must be changed in part 2:
    AspPrimary ap = new AspPrimary(s.curLineNum());
    ap.body = AspAtom.parse(s);
    boolean wasInside = false;
    while(true){
        if (s.curToken().kind == leftParToken || s.curToken().kind == leftBracketToken){
        ap.primarySuffixs.add(AspPrimarySuffix.parse(s));
        wasInside = true;
      }
      if(wasInside == false) break;
      wasInside = false;
    }

    leaveParser("primary");
    return ap;
  }


  @Override
  public void prettyPrint() {
    //-- Must be changed in part 2:
    body.prettyPrint();
    int nPrinted = 0;
    for (AspPrimarySuffix aps: primarySuffixs) {
      aps.prettyPrint();
    }
  }


  @Override
  public RuntimeValue eval(RuntimeScope curScope) throws RuntimeReturnValue {
    //-- Must be changed in part 3:
    RuntimeValue v = body.eval(curScope);
    for(AspPrimarySuffix aps: primarySuffixs){
      if(aps instanceof AspSubscription){
        v = v.evalSubscription(aps.eval(curScope) ,this);
      }
      if(aps instanceof AspArguments){
        RuntimeListValue w = (RuntimeListValue) aps.eval(curScope);
        String output = "Call function " + v.toString() + " with params "+ w.showInfo();
        trace(output);
        v = v.evalFuncCall(w.exprs,this);
      }
    }
    return v;
  }
}
