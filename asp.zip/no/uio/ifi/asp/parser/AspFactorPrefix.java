package no.uio.ifi.asp.parser;
import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.runtime.*;
import no.uio.ifi.asp.scanner.*;
import static no.uio.ifi.asp.scanner.TokenKind.*;

public class AspFactorPrefix extends AspSyntax {
  int whatTokenType = 0;
  TokenKind kind;

  AspFactorPrefix(int n) {
    super(n);
  }

  public static AspFactorPrefix parse(Scanner s) {
    enterParser("factor prefix");

    //-- Must be changed in part 2:
    AspFactorPrefix afp = new AspFactorPrefix(s.curLineNum());
    switch (s.curToken().kind) {
      case plusToken:
        afp.kind = s.curToken().kind; s.readNextToken(); afp.whatTokenType = 1; break;
      case minusToken:
        afp.kind = s.curToken().kind; s.readNextToken(); afp.whatTokenType = 2; break;
      default:
        parserError("Expected an expression factor prefix but found a " + s.curToken().kind + "!", s.curLineNum());
    }

    leaveParser("factor prefix");
    return afp;
  }


  @Override
  public void prettyPrint() {
    //-- Must be changed in part 2:
    if(whatTokenType == 1){
      Main.log.prettyWrite(" + ");
    }else if(whatTokenType == 2){
      Main.log.prettyWrite(" - ");
    }
  }


  @Override
  public RuntimeValue eval(RuntimeScope curScope) throws RuntimeReturnValue {
    //-- Must be changed in part 3:
    return null;
  }
}
