package no.uio.ifi.asp.parser;
import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.runtime.*;
import no.uio.ifi.asp.scanner.*;
import static no.uio.ifi.asp.scanner.TokenKind.*;

public class AspInnerExpr extends AspAtom {
  AspExpr test;

  AspInnerExpr(int n) {
    super(n);
  }

  public static AspInnerExpr parse(Scanner s) {
    enterParser("inner expr");

    //-- Must be changed in part 2:
    AspInnerExpr aie = new AspInnerExpr(s.curLineNum());
    skip(s, leftParToken);
    aie.test = AspExpr.parse(s);
    skip(s,rightParToken);

    leaveParser("inner expr");
    return aie;
  }


  @Override
  public void prettyPrint() {
    //-- Must be changed in part 2:
    Main.log.prettyWrite(" ( ");
    test.prettyPrint();
    Main.log.prettyWrite(" ) ");
  }


  @Override
  public RuntimeValue eval(RuntimeScope curScope) throws RuntimeReturnValue {
    //-- Must be changed in part 3:
    RuntimeValue e = test.eval(curScope);
    return e;
  }
}
