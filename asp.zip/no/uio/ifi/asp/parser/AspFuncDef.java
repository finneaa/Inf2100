package no.uio.ifi.asp.parser;
import java.util.ArrayList;

import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.runtime.*;
import no.uio.ifi.asp.scanner.*;
import static no.uio.ifi.asp.scanner.TokenKind.*;

public class AspFuncDef extends AspStmt {
  public ArrayList<AspName> names = new ArrayList<>();
  public AspSuite body;

  AspFuncDef(int n) {
    super(n);
  }

  public static AspFuncDef parse(Scanner s) {
    enterParser("func def");

    //-- Must be changed in part 2:
    AspFuncDef afd = new AspFuncDef(s.curLineNum());
    skip(s,defToken);
    afd.names.add(AspName.parse(s));
    skip(s, leftParToken);
    while(true){
      if(s.curToken().kind == rightParToken) break;
      afd.names.add(AspName.parse(s));
      if (s.curToken().kind != commaToken) break;
      skip(s, commaToken);
    }
    skip(s, rightParToken);
    skip(s, colonToken);
    afd.body = AspSuite.parse(s);

    leaveParser("func def");
    return afd;
  }


  @Override
  public void prettyPrint() {
    //-- Must be changed in part 2:
    Main.log.prettyWrite(" def ");
    names.get(0).prettyPrint();
    Main.log.prettyWrite(" ( ");
    if(names.size() > 1){
      for (int nPrinted = 1; nPrinted < names.size();nPrinted ++) {
        if (nPrinted > 1){
          Main.log.prettyWrite(" , ");
        }
        names.get(nPrinted).prettyPrint();
      }
    }
    Main.log.prettyWrite(" ) : ");
    body.prettyPrint();
  }


  @Override
  public RuntimeValue eval(RuntimeScope curScope) throws RuntimeReturnValue {
    //-- Must be changed in part 4:
    //har funksjon?
    //if(curScope.find(names.get(0).nameValue, this) != null);
    trace("def " +  names.get(0).nameValue);
    curScope.assign(names.get(0).nameValue , new RuntimeFunc(names.get(0).nameValue, curScope, this));
    return null;
  }
}
