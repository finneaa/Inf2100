package no.uio.ifi.asp.parser;
import java.util.ArrayList;

import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.runtime.*;
import no.uio.ifi.asp.scanner.*;
import static no.uio.ifi.asp.scanner.TokenKind.*;

public class AspTermOpr extends AspSyntax {
  int whatTokenType = 0;
  TokenKind kind;

  AspTermOpr(int n) {
    super(n);
  }

  public static AspTermOpr parse(Scanner s) {
    enterParser("term opr");

    //-- Must be changed in part 2:
    AspTermOpr ato = new AspTermOpr(s.curLineNum());
    switch (s.curToken().kind) {
      case plusToken:
        ato.kind = s.curToken().kind; s.readNextToken(); ato.whatTokenType = 1; break;
      case minusToken:
        ato.kind = s.curToken().kind; s.readNextToken(); ato.whatTokenType = 2; break;
      default:
        parserError("Expected an expression term opr but found a " + s.curToken().kind + "!", s.curLineNum());
    }

    leaveParser("term opr");
    return ato;
  }


  @Override
  public void prettyPrint() {
    //-- Must be changed in part 2:
    if(whatTokenType == 1){
      Main.log.prettyWrite(" + ");
    }else if(whatTokenType == 2){
      Main.log.prettyWrite(" - ");
    }
  }


  @Override
  public RuntimeValue eval(RuntimeScope curScope) throws RuntimeReturnValue {
    //-- Must be changed in part 3:
    return null;
  }
}
