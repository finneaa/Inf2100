package no.uio.ifi.asp.parser;
import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.runtime.*;
import no.uio.ifi.asp.scanner.*;
import static no.uio.ifi.asp.scanner.TokenKind.*;

public abstract class AspPrimarySuffix extends AspSyntax {

  AspPrimarySuffix(int n) {
    super(n);
  }

  public static AspPrimarySuffix parse(Scanner s) {
    enterParser("primary suffix");

    //-- Must be changed in part 2:
    AspPrimarySuffix apf = null;
    switch (s.curToken().kind) {
      case leftParToken:
        apf = AspArguments.parse(s); break;
      case leftBracketToken:
        apf = AspSubscription.parse(s); break;
      default:
        parserError("Expected an expression primary suffix but found a " + s.curToken().kind + "!", s.curLineNum());
    }

    leaveParser("primary suffix");
    return apf;
  }

}
