package no.uio.ifi.asp.parser;
import no.uio.ifi.asp.main.*;
import no.uio.ifi.asp.runtime.*;
import no.uio.ifi.asp.scanner.*;
import static no.uio.ifi.asp.scanner.TokenKind.*;

public class AspReturnStmt extends AspStmt {
  AspExpr body;

  AspReturnStmt(int n) {
    super(n);
  }

  public static AspReturnStmt parse(Scanner s) {
    enterParser("return stmt");

    //-- Must be changed in part 2:
    AspReturnStmt ars = new AspReturnStmt(s.curLineNum());
    skip(s, returnToken);
    ars.body = AspExpr.parse(s);
    skip(s, newLineToken);

    leaveParser("return stmt");
    return ars;
  }


  @Override
  public void prettyPrint() {
    //-- Must be changed in part 2:
    Main.log.prettyWrite(" return ");
    body.prettyPrint();
    Main.log.prettyWriteLn();
  }


  @Override
  public RuntimeValue eval(RuntimeScope curScope) throws RuntimeReturnValue {
    RuntimeValue v = body.eval(curScope);
    trace("return "+v.showInfo());
    throw new RuntimeReturnValue(v,lineNum);
  }
}
